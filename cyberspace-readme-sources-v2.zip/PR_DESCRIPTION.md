## Objet
Mise à jour du README et de docs/sources.md pour les aligner sur l'énoncé complet du défi.

## README
- Ajout du 4e scénario « Ressources (glace, ISRU) » issu de sources.md
- Tableau scénarios → variables → sources
- Proposition de public cible (à valider)
- Affichage par site : score global, score par critère, ce qui correspond / ne correspond pas
- Sections « Validation » et « Limites de l'analogie terrestre »
- Lien vers docs/sources.md

## docs/sources.md (ajouts uniquement, rien de supprimé)
- MODIS NDVI (filtre sol nu) et Trek WMTS (fonds de carte) : socle
- GLiM passée de priorité 3 à 2
- HLS, SRTM, aérosols, nouveau catalogue de cratères : compléments
- Nouvelle section « Couverture des dimensions du défi »
- Toutes les nouvelles sources sont marquées « À tester »

## À trancher en revue
- [ ] Public cible
- [ ] Lune seulement ou Lune + Mars (MOLA / THEMIS dans le socle ?)
- [ ] Modèle(s) Claude utilisé(s)
